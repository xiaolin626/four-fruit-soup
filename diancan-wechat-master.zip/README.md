# diancan-wechat

#### 介绍
一个外卖点餐系统，类似麦当劳的简单选品，下单，包含前端和后端，这个是微信小程序前端。




#### 安装教程

1. APPid: wx3fca350c954ae1a1
2. 后端地址： 如果需要后端接口地址请联系 加V: 18850737047
3. 前端请求接口地址：存放在 utils/config.js

#### 提示
1. 请先去微信公众平台注册一个个人版小程序账户
2. 下载开发工具
3. 导入这个项目，在工具中把不校验https监测，打上勾，否则无法请求数据

####图片

![11](https://img-blog.csdnimg.cn/7bc3f8e80ec74570a9280d9b003b176d.png?x-oss-process=image/watermark,type_d3F5LXplbmhlaQ,shadow_50,text_Q1NETiBAa2V2aW4ubGl1,size_11,color_FFFFFF,t_70,g_se,x_16#pic_center"11")

![11](https://img-blog.csdnimg.cn/f12c50a675b5430b98f30eba83c76654.png?x-oss-process=image/watermark,type_d3F5LXplbmhlaQ,shadow_50,text_Q1NETiBAa2V2aW4ubGl1,size_11,color_FFFFFF,t_70,g_se,x_16#pic_center"11")

![22](https://img-blog.csdnimg.cn/2fd2b365cd3b4bb59ae499a32c0ac32d.png?x-oss-process=image/watermark,type_d3F5LXplbmhlaQ,shadow_50,text_Q1NETiBAa2V2aW4ubGl1,size_11,color_FFFFFF,t_70,g_se,x_16#pic_center"11")

![33](https://img-blog.csdnimg.cn/116dd2faec75429e9d31b9deb820aa47.png?x-oss-process=image/watermark,type_d3F5LXplbmhlaQ,shadow_50,text_Q1NETiBAa2V2aW4ubGl1,size_11,color_FFFFFF,t_70,g_se,x_16#pic_center"11")

![44](https://img-blog.csdnimg.cn/d79a06c4e8814ef4bdfd3faed253702d.png?x-oss-process=image/watermark,type_d3F5LXplbmhlaQ,shadow_50,text_Q1NETiBAa2V2aW4ubGl1,size_11,color_FFFFFF,t_70,g_se,x_16#pic_center"11")



